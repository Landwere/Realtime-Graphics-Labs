#include "Renderable.hpp"

namespace glhelper {

Renderable::Renderable(const Eigen::Matrix4f &modelToWorld)
:Entity(modelToWorld)
{
	
}

}
